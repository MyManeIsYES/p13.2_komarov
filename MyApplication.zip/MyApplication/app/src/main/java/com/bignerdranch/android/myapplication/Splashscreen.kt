package com.bignerdranch.android.myapplication

import android.content.Intent
import android.content.IntentSender.OnFinished
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer

class Splashscreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splashscreen)
        var timer1= object : CountDownTimer (3000,1000) {
            override fun onTick(millisUntilFinished: Long) {

            }

            override fun onFinish() {
                val intent = Intent(this@Splashscreen, onboarding::class.java)
                startActivity(intent)
                finish()

            }
        }
        timer1.start()
    }
}